chrome.runtime.onInstalled.addListener(() => {
    console.log("Hide Gorilla Tag Comments extension installed.");
  });
  