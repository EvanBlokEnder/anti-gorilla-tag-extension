// Function to hide comments based on profile picture or username
function hideGorillaTagComments() {
    const comments = document.querySelectorAll('#content-text');  // Select all comment texts
  
    comments.forEach(comment => {
      const username = comment.closest('ytd-comment-thread-renderer').querySelector('#author-text').textContent.toLowerCase();
      const profilePic = comment.closest('ytd-comment-thread-renderer').querySelector('#img').src;
  
      // Check if the username contains "gtag" or the profile picture matches Gorilla Tag image pattern
      if (username.includes('gtag') || isGorillaTagProfilePicture(profilePic)) {
        const commentElement = comment.closest('ytd-comment-thread-renderer');
        commentElement.style.display = 'none';  // Hide comment
      }
    });
  }
  
  // Function to determine if the profile picture matches a Gorilla Tag profile image
  // This can be improved by checking image URLs for known Gorilla Tag profile pics.
  function isGorillaTagProfilePicture(profilePic) {
    // Add logic to identify specific Gorilla Tag profile picture URLs or patterns
    const gorillaTagImageUrls = [
      'https://wallpapers-clan.com/wp-content/uploads/2022/07/gorilla-tag-1.jpg'  // Replace with real URLs
    ];
    
    return gorillaTagImageUrls.some(url => profilePic.includes(url));
  }
  
  // Run the function to hide comments on page load
  window.addEventListener('load', hideGorillaTagComments);
  